# 阿里云音乐预测大赛拟合数据信息

* Generalized Linear Models  
	- Ordinary Least Squares  [简书-更多详细内容](http://www.jianshu.com/p/ab96b1f5e75d)

![Ordinary Least Squares](./Generalized_Linear_Models/img/Ordinary_Least_Squares.png)

 
