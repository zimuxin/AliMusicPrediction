import os,sys,time

import csv
import matplotlib.pyplot as plt
from matplotlib.legend_handler import HandlerLine2D
import os,sys
path = os.getcwd()
parent_path = os.path.dirname(path)
parent_path = os.path.dirname(parent_path)
print(parent_path)